Markov Decision Process

python value_iteration.py environment2.txt -0.04 1 20
python value_iteration.py environment2.txt -0.04 0.9 20
